#!/bin/sh
set -x
/emulator/retroplayer ./emu/bash_launcher_libretro.so "./roms/RUN.sh"
