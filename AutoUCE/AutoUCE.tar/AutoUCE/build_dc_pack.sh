#!/bin/bash

# Welcome message
echo "===== Welcome to UCE packageing tool. ====="
echo "===== This tool is for DC game only. ====="

# Force set working directory
AddOn_WORK="AddOn_WORK"

# Check template.tar
if [ ! -f "template.tar" ]; then
    echo "Error: template.tar does not exists."
    exit 1
fi

# Reset working folder
rm -r template/
tar -xf template.tar
rm -r AddOn_WORK
mkdir -p AddOn_WORK/boxart
mkdir -p AddOn_WORK/emu
mkdir -p AddOn_WORK/roms
cp template/exec.sh AddOn_WORK/exec.sh
cp template/cartridge.xml AddOn_WORK/cartridge.xml
cp template/RUN_DC.sh AddOn_WORK/roms/RUN.sh

# Rename cartridge.xml
read -p "Please enter UCE title:" TITLE
sed -i "s/GAME/${TITLE}/g" AddOn_WORK/cartridge.xml

# Force set output file name
OUTPUT="AddOn_${TITLE}.UCE"

# Ask path of GAME.chd
read -p "Please enter absolute path of rom (only support .chd format):" ROM
cp ${ROM} AddOn_WORK/emu/GAME.chd

# Ask path of reicast.elf
read -p "Please enter absolute path of reicast.elf:" REICAST
cp ${REICAST} AddOn_WORK/emu/reicast.elf

# Ask path of bash_launcher_libretro.so
read -p "Please enter absolute path of bash_launcher_libretro.so:" BASHLAUNCHER
cp ${BASHLAUNCHER} AddOn_WORK/emu/bash_launcher_libretro.so

# Ask path of boxart
read -p "Please enter absolute path of boxart:" BOXART
cp ${BOXART} AddOn_WORK/boxart/boxart.png
cp ${BOXART} AddOn_WORK/title.png

# Fix files permission 
sudo chmod -R 755 AddOn_WORK/

##############
# Original UCE sh#
##############


#cart_file=./byog_cartridge_shfs.img
cart_file=${OUTPUT}
cart_tmp_file=./byog_cartridge_shfs_temp.img
cart_save_file=./byog_cart_saving_ext4.img
squash_mount_point=./squashfs
ext4_saving_mount_point=./saving

cart_saving_size=4M
 
if [ -e "$cart_tmp_file" ]; then
    rm -f $cart_tmp_file
fi
 
if [ -e "$cart_save_file" ]; then
    rm -f $cart_save_file
fi

#with gzip, block size set as 256K 

sudo chmod 755 AddOn_WORK/exec.sh
mksquashfs AddOn_WORK $cart_tmp_file -comp gzip -b 262144 -root-owned -nopad
 
SQIMGFILESIZE=$(stat -c%s "$cart_tmp_file")
echo "*** Size of $cart_tmp_file: $SQIMGFILESIZE Bytes (before applying 4k alignment)"
 
 
REAL_BYTES_USED_DIVIDED_BY_4K=$((SQIMGFILESIZE/4096))
if  [ $((SQIMGFILESIZE % 4096)) != 0 ]
then
  REAL_BYTES_USED_DIVIDED_BY_4K=$((REAL_BYTES_USED_DIVIDED_BY_4K+1))
fi
REAL_BYTES_USED=$((REAL_BYTES_USED_DIVIDED_BY_4K*4096))
 
dd if=/dev/zero bs=1 count=$((REAL_BYTES_USED-SQIMGFILESIZE)) >> $cart_tmp_file
 
SQIMGFILESIZE=$(stat -c%s "$cart_tmp_file")
echo "*** Size of $cart_tmp_file: $SQIMGFILESIZE Bytes (after applying 4k alignment)"
 
my_md5string_hex_file=./my_md5string_hex.bin
 
 
# header padding 64 bytes
EXT4FILE_OFFSET=$((SQIMGFILESIZE+64));
echo "*** Offset of Ext4 partition for file saving would be: $EXT4FILE_OFFSET"
 
md5=$(md5sum "$cart_tmp_file" | cut -d ' '  -f 1)
echo "*** SQFS Partition MD5 Hash: "$md5""
echo $md5 | xxd -r -p > $my_md5string_hex_file
dd if=$my_md5string_hex_file of=$cart_tmp_file ibs=16 count=1 obs=16 oflag=append conv=notrunc
dd if=/dev/zero of=$cart_tmp_file ibs=16 count=2 obs=16 oflag=append conv=notrunc
 
if [ -e "$my_md5string_hex_file" ]; then
    rm -f $my_md5string_hex_file
fi
 
truncate -s $cart_saving_size $cart_save_file
mkfs.ext4 $cart_save_file
debugfs -R 'mkdir upper' -w $cart_save_file
debugfs -R 'mkdir work' -w $cart_save_file
 
md5=$(md5sum "$cart_save_file" | cut -d ' '  -f 1)
echo "*** Ext4 Partition MD5 Hash: "$md5""
echo $md5 | xxd -r -p > $my_md5string_hex_file
dd if=$my_md5string_hex_file of=$cart_tmp_file ibs=16 count=1 obs=16 oflag=append conv=notrunc
 
#bind files together
cat $cart_tmp_file $cart_save_file > $cart_file
 
if [ -e "$my_md5string_hex_file" ]; then
    rm -f $my_md5string_hex_file
fi
 
if [ -e "$cart_tmp_file" ]; then
    rm -f $cart_tmp_file
fi
 
if [ -e "$cart_save_file" ]; then
    rm -f $cart_save_file
fi

# Delete working folder
rm -r template/
rm -r AddOn_WORK

# Show complete message
echo "UCE bulit complete!"
echo ""
echo ""
echo "===== Note for Flycast Setting ====="
echo "Connect an USB keyboard before lunching UCE. After launch UCE, press tab to bring up setting menu. Use arrow key to navigate, X to confirm, C to cancle."
