#!/bin/sh
set -x
export HOME=../SAVE/upper
./emu/reicast.elf ./emu/GAME.chd
